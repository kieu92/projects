import processing.core.PApplet;

public class UsingProcessing extends PApplet{

	public static void main(String[] args) {
		//PApplet.main("UsingProcessing");
	}
	
	public void settings(){
		size(400, 400);
    }

    public void setup(){
    	background(255);
    	noStroke();
    	fill(0, 0, 255);
    	ellipse(200, 200, 50, 50);
    }

    public void draw(){

    }


}
